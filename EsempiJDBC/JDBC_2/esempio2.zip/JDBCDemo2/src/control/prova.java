package control;



import entity.EntityStudente;

public class prova {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityStudente s = new EntityStudente("M6300001");
				
		System.out.println(s);
		
		//System.out.println(s.getCorsi());
		

		
	}

}
