package control;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import entity.EntityStudente;

public class prova {



	
	public static void main(String[] args) throws ClassNotFoundException, SQLException{
		// TODO Auto-generated method stub


		EntityStudente s = new EntityStudente("1");
		
		System.out.println(s);
		
		
}

}



























