package exceptions;

public class DataNonValida extends Exception{
	
	public DataNonValida() {
		super();
	}
	
	public String toString() {
		return "[ECCEZIONE] Data Non Valida!";
	}
	
}
