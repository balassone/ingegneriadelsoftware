package boundary;

import control.Controller;

public class test {

	public static void main(String[] args) {
			
		System.out.println("Ciao");
		System.out.println(Controller.trovaAgente("ABCDEF00D11H123N"));

	}

}
